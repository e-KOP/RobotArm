#!/usr/bin/env python3
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, TimerAction
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    # --- Get paths inside this package ---
    pkg_share = get_package_share_directory('robotic_sorter')
    urdf_path = os.path.join(pkg_share, 'urdf', 'robot.urdf.xacro')
    rviz_config_path = os.path.join(pkg_share, 'rviz', 'view.rviz')

    # --- Launch argument: use simulation time ---
    use_sim_time = LaunchConfiguration('use_sim_time')

    # --- Convert Xacro to URDF  ---
    robot_description_cmd = Command(['xacro ', urdf_path])
    robot_description = ParameterValue(robot_description_cmd, value_type=str)
    
    # --- Node 1: Joint State Publisher GUI ---
    # Lets you move sliders for each joint to test robot kinematics
    joint_state_publisher_gui_node = Node(
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        name='joint_state_publisher_gui',
        output='screen',
    )

    # --- Node 2: Robot State Publisher ---
    # Publishes /tf and /robot_description using the URDF model
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description,
            'use_sim_time': use_sim_time
        }],
    )

    # --- Node 3: RViz2 (visualization) ---
    # Starts RViz and loads a predefined configuration file
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config_path],
    )

    # --- Delay RViz startup by 5 seconds ---
    # Ensures TF and robot_state_publisher are running before RViz starts
    delay_rviz_node = TimerAction(
        period=5.0,
        actions=[rviz_node],
    )

    # --- Return the full LaunchDescription ---
    return LaunchDescription([
        DeclareLaunchArgument(
            'use_sim_time', default_value='true',
            description='Use simulation time if true'
        ),
        joint_state_publisher_gui_node,
        robot_state_publisher_node,
        delay_rviz_node,
    ])
