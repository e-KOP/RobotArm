#!/usr/bin/env python3
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, TimerAction, IncludeLaunchDescription, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration, TextSubstitution
from launch_ros.actions import Node
import xacro, subprocess, tempfile
from launch_ros.parameter_descriptions import ParameterValue
from datetime import datetime
import pathlib, json

def generate_launch_description():
    # --- Get paths inside this package ---
    pkg_share = get_package_share_directory('robotic_sorter')
    urdf_path =          os.path.join(pkg_share, 'urdf', 'robot.urdf.xacro')
    rviz_config_path =   os.path.join(pkg_share, 'rviz', 'view.rviz')
    world_sdf_path =     os.path.join(pkg_share, 'world', 'world.sdf')
    bridge_config_path = os.path.join(pkg_share, 'config', 'gz_bridge.yaml')

    ros_gz_sim_pkg = get_package_share_directory('ros_gz_sim')
    gz_launch =          os.path.join(ros_gz_sim_pkg, 'launch', 'gz_sim.launch.py')

    # --- Launch argument: use simulation time ---
    use_sim_time = LaunchConfiguration('use_sim_time')
    # verbose      = LaunchConfiguration('verbose')  # e.g. '4'

    # # --- Convert Xacro to URDF  ---
    # robot_description = Command(['xacro ', urdf_path])
    #robot_description = ParameterValue(robot_description_cmd, value_type=str)

    # # 1) xacro -> URDF (string)
    # urdf_xml = xacro.process_file(urdf_path).toxml()
    # # 2) write temp URDF file
    # with tempfile.NamedTemporaryFile('w', delete=False, suffix='.urdf') as f:
    #     f.write(urdf_xml)
    #     urdf_out = f.name
    # # 3) URDF -> SDF (string)
    # sdf_xml = subprocess.check_output(['gz', 'sdf', '-p', urdf_out]).decode()
    # # 4) write temp SDF file  <-- this was missing
    # with tempfile.NamedTemporaryFile('w', delete=False, suffix='.sdf') as f:
    #     f.write(sdf_xml)
    #     robot_sdf_path = f.name


    # 1) xacro -> URDF (string)
    urdf_xml = xacro.process_file(urdf_path).toxml()

    # --- Dump pretty copies to /tmp for debugging ---
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    dump_dir = pathlib.Path("/tmp/robotic_sorter_dumps")
    dump_dir.mkdir(parents=True, exist_ok=True)
    urdf_dump_path = dump_dir / f"robotic_sorter_{stamp}.urdf"

    with open(urdf_dump_path, "w") as f:
        f.write(urdf_xml)
    print(f"[gz_bringup] Wrote URDF to: {urdf_dump_path}")

    # 2) write temp URDF file (for gz sdf -p)
    with tempfile.NamedTemporaryFile('w', delete=False, suffix='.urdf') as f:
        f.write(urdf_xml)
        urdf_out = f.name

    # 3) URDF -> SDF (string)
    sdf_xml = subprocess.check_output(['gz', 'sdf', '-p', urdf_out]).decode()

    # --- Dump SDF pretty copy to /tmp as well ---
    sdf_dump_path = dump_dir / f"robotic_sorter_{stamp}.sdf"
    with open(sdf_dump_path, "w") as f:
        f.write(sdf_xml)
    print(f"[gz_bringup] Wrote SDF to:  {sdf_dump_path}")

    # 4) write temp SDF file for spawn
    with tempfile.NamedTemporaryFile('w', delete=False, suffix='.sdf') as f:
        f.write(sdf_xml)
        robot_sdf_path = f.name



    set_gz_resource = SetEnvironmentVariable(
        name='GZ_SIM_RESOURCE_PATH',
        value=f"{pkg_share}:{os.environ.get('GZ_SIM_RESOURCE_PATH','')}"
    )

    set_render_env = SetEnvironmentVariable(
        name='GZ_RENDER_ENGINE',
        value='ogre2'
    )
    # --- Node 1: Joint State Publisher GUI ---
    # Lets you move sliders for each joint to test robot kinematics
    joint_state_publisher_gui_node = Node(
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        name='joint_state_publisher_gui',
        output='screen',
    )

    # --- Node 2: Robot State Publisher ---
    # Publishes /tf and /robot_description using the URDF model
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': urdf_xml,
            'use_sim_time': use_sim_time
        }],
    )




    # --- Node 3: RViz2 (visualization) ---
    # Starts RViz and loads a predefined configuration file
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config_path],
    )

    # set_render_env = SetEnvironmentVariable(name='GZ_RENDER_ENGINE', value='ogre2')


    # --- Node 4: gazebo launch with world ---
    gz_world = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(gz_launch),
        launch_arguments={
            # 'gz_args': f'-s -r -v 4 {world_sdf_path}',  # server + run + verbose + world
            'gz_args': f'-r {world_sdf_path}',  # GUI + server, run immediately
            'gz_version': '8'
        }.items()
    )


    # gz_world = IncludeLaunchDescription(
    #     PythonLaunchDescriptionSource(gz_launch),
    #     launch_arguments={
    #         'gz_args': TextSubstitution(text=f"-v 4 -r {world_sdf_path}"),
    #         'gz_version': '8',
    #     }.items()
    # )
    # # --- Node 5: Spawn robot into Gazebo from /robot_description ---
    # ros_gz_sim create will insert the entity into the running gz sim





    spawn_robot =           Node(
        package='ros_gz_sim',
        executable='create',
        name='spawn_robotic_sorter',
        output='screen',
        arguments=[
            #'-topic', 'robot_description',
            '-file', robot_sdf_path,
            '-name', 'robotic_sorter',
            # Optional placement: uncomment to set initial pose
            '-x', '0.4', '-y', '0.2', '-z', '0.8',
            '-R', '0.0', '-P', '0.0', '-Y', '1.57'
        ],
    )


    # --- Node 6: Bridge Gazebo and ROS ---

    ros_gz_bridge =         Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        name='gz_parameter_bridge',
        output='screen',
        parameters=[{'config_file': bridge_config_path}],  
        # arguments=['--ros-args', '-p', f'config_file:={bridge_config_path}']
    )

    # controller_manager_node = Node(
    #     package='controller_manager',
    #     executable='ros2_control_node',
    #     name='controller_manager',
    #     output='screen',
    #     parameters=[
    #         {'robot_description': urdf_xml,
    #         'use_sim_time': use_sim_time},
    #         controllers_yaml_path,   # your ros2_control.yaml
    #     ],
    # )






    spawner_jsb =           Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster', '--controller-manager', '/controller_manager'],
        output='screen',
        name='spawner_joint_state_broadcaster'
    )

    spawner_arm_ctl =       Node(
        package='controller_manager',
        executable='spawner',
        arguments=['arm_controller', '--controller-manager', '/controller_manager'],
        output='screen',
        name='spawner_arm_controller'
    )

    spawner_gripper_ctl =   Node(
        package='controller_manager',
        executable='spawner',
        arguments=['gripper_controller', '--controller-manager', '/controller_manager'],
        output='screen',
        name='spawner_gripper_controller'
    )

    # --- Return the full LaunchDescription ---
    return LaunchDescription([
        DeclareLaunchArgument(
            'use_sim_time', default_value='true',
            description='Use simulation time if true'
        ),
        set_gz_resource,
        set_render_env,
        joint_state_publisher_gui_node,
        robot_state_publisher_node,

        # set_render_env,
        # Gazebo Sim bringup + spawn + controllers
        gz_world,
        TimerAction(period=2.0, actions=[spawn_robot]),
        ros_gz_bridge,
        # TimerAction(period=5.0, actions=[spawner_jsb]),
        # # TimerAction(period=5.0, actions=[spawner_arm_ctl]),
        # # TimerAction(period=5.0, actions=[spawner_gripper_ctl]),
        # # RViz Launch
        TimerAction(period=5.0, actions=[rviz_node]),
    
        # joint_state_publisher_gui_node,
    ])
