import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'robotic_sorter'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name,                     ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob(os.path.join('launch', '*.*'))),
        (os.path.join('share', package_name, 'urdf'  ), glob(os.path.join('urdf'  , '*.*'))),
        (os.path.join('share', package_name, 'rviz'  ), glob(os.path.join('rviz'  , '*.*'))),
        (os.path.join('share', package_name, 'meshes'), glob(os.path.join('meshes', '*.*'))),
        (os.path.join('share', package_name, 'config'), glob(os.path.join('config', '*.*'))),
        (os.path.join('share', package_name, 'world' ), glob(os.path.join('world' , '*.*'))),


    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Zhongye Xue',
    maintainer_email='zhxue0231@oslomet.no',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
        ],
    },
)
